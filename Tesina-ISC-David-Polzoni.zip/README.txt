# Struttura Tesina-ISC-David-Polzoni.zip [start] #

1. src: codice sorgente del software sviluppato;
2. tesina: PDF della tesina.

# Struttura Tesina-ISC-David-Polzoni.zip [end] #

# Esecuzione codice sorgente Python [start] #

1. Da linea di comando: python particle_tajectory.py;
2. IDE (e.g. PyCharm): eseguire particle_trajectory.py tramite l'IDE utilizzata.

# Esecuzione codice sorgente Python [end] #